basic_sentiment_analysis
========================

Code of the blog post: http://fjavieralba.com/basic-sentiment-analysis-with-python.html